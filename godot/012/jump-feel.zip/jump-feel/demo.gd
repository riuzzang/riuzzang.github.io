extends Control
## Shows each jump helper switched off (top lane) and on (bottom lane).
## Both lanes get the very same scripted button presses, so the only
## difference on screen is the helper itself.
##
## The game picture is drawn at half the window size and shown at exactly 2x:
## one dot is always 2x2 pixels, and a bigger window sees more, not bigger dots.

const PlayerScript := preload("res://player.gd")
const LANE_LEN := 800.0
const SECONDS_EACH := 7.0
const OFF_COLOR := Color("f0785a")
const ON_COLOR := Color("5bd18a")

enum Mode { COYOTE, BUFFER, VARIABLE }

const SHOWS := [
	{"mode": Mode.COYOTE, "title": "1. 코요테 타임", "sub": "발판 끝을 살짝 지나서 눌러도 점프"},
	{"mode": Mode.BUFFER, "title": "2. 점프 버퍼", "sub": "착지 직전에 미리 눌러도 점프"},
	{"mode": Mode.VARIABLE, "title": "3. 가변 점프", "sub": "짧게 누르면 낮게, 길게 누르면 높게"},
]

var view: SubViewport
var world: Node2D
var ui: CanvasLayer
var title: Label
var sub: Label
var lane_labels: Array[Label] = []
var lanes: Array[Dictionary] = []
var show_index := -1
var clock := 0.0
var shake := 0.0
var sounds := {}
var rng := RandomNumberGenerator.new()


## The same button presses for both lanes, decided from what the player is doing.
class Pilot:
	var mode: int
	var axis := 1.0
	var pressed := false
	var held := false
	var hold := 0
	var fired := false
	var countdown := -1
	var prev_floor := false

	func reset() -> void:
		pressed = false
		held = false
		hold = 0
		fired = false
		countdown = -1
		prev_floor = false

	func press(frames: int) -> void:
		pressed = true
		hold = frames
		fired = true

	func update(p: CharacterBody2D) -> void:
		pressed = false
		var on_floor := p.is_on_floor()
		match mode:
			Mode.COYOTE:
				# A little late: five frames after walking off the edge.
				if prev_floor and not on_floor and not fired and countdown < 0:
					countdown = 5
				if countdown > 0:
					countdown -= 1
					if countdown == 0:
						press(14)
			Mode.BUFFER:
				# A little early: a few frames before the feet touch down.
				if not fired and p.position.x > 180.0 and p.velocity.y > 0.0 and p.position.y > -48.0:
					press(14)
			Mode.VARIABLE:
				# A short tap in front of the block.
				if not fired and p.position.x >= 360.0:
					press(3)
		prev_floor = on_floor
		held = hold > 0
		hold -= 1


## The body of the player: a few dots, drawn in code, origin at the feet.
class Look:
	extends Node2D
	var color := Color.WHITE

	func _draw() -> void:
		var dark := Color("1b1f27")
		draw_rect(Rect2(-12, -28, 24, 28), color.darkened(0.35))   # outline
		draw_rect(Rect2(-11, -27, 22, 26), color)
		draw_rect(Rect2(-11, -27, 22, 5), color.lightened(0.3))    # light from above
		draw_rect(Rect2(-11, -8, 22, 7), color.darkened(0.15))     # belly shade
		draw_rect(Rect2(1, -20, 4, 7), dark)                        # eyes, looking right
		draw_rect(Rect2(7, -20, 4, 7), dark)
		draw_rect(Rect2(2, -19, 1, 2), Color.WHITE)
		draw_rect(Rect2(8, -19, 1, 2), Color.WHITE)
		draw_rect(Rect2(-11, -3, 8, 3), color.darkened(0.4))        # feet
		draw_rect(Rect2(3, -3, 8, 3), color.darkened(0.4))


## Ground, pits and spikes of one lane.
class Painter:
	extends Node2D
	var def: Dictionary

	func _draw() -> void:
		draw_rect(Rect2(-40, -150, LANE_LEN + 80, 196), Color(1, 1, 1, 0.035))
		for r: Rect2 in def.solids:
			draw_rect(r, Color("3b3350"))
			draw_rect(Rect2(r.position, Vector2(r.size.x, minf(3.0, r.size.y))), Color("8f86b8"))
			# Speckles, placed by a fixed formula so every run looks the same.
			var n := int(r.size.x * r.size.y / 60.0)
			for i in n:
				var x := r.position.x + fmod(i * 37.0 + 11.0, maxf(r.size.x - 2.0, 1.0))
				var y := r.position.y + 5.0 + fmod(i * 53.0 + 7.0, maxf(r.size.y - 7.0, 1.0))
				if y < r.end.y - 2.0:
					draw_rect(Rect2(floorf(x), floorf(y), 1, 1), Color("2c2640"))
		for r: Rect2 in def.hazards:
			draw_rect(Rect2(r.position, r.size - Vector2(0, 6)), Color("5a1f2b"))
			var x := r.position.x
			while x < r.end.x:
				draw_colored_polygon(PackedVector2Array([
					Vector2(x, r.end.y - 6), Vector2(x + 8, r.end.y - 6), Vector2(x + 4, r.end.y)]), Color("ff5a6e"))
				x += 8.0


func _ready() -> void:
	rng.seed = 12
	RenderingServer.set_default_clear_color(Color("161a26"))
	var box := SubViewportContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.stretch = true
	box.stretch_shrink = 2
	box.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(box)
	view = SubViewport.new()
	view.audio_listener_enable_2d = true
	view.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	box.add_child(view)
	world = Node2D.new()
	view.add_child(world)

	# Text is drawn on top at full sharpness so it stays readable.
	ui = CanvasLayer.new()
	add_child(ui)
	title = _label(64, Color.WHITE)
	title.position = Vector2(96, 40)
	sub = _label(36, Color("9fb4d0"))
	sub.position = Vector2(100, 126)

	sounds = {
		"jump": _tone(300.0, 640.0, 0.12, 0.0, 0.35),
		"land": _tone(150.0, 60.0, 0.10, 0.6, 0.45),
		"die": _tone(520.0, 70.0, 0.36, 0.35, 0.5),
	}


func _label(font_size: int, color: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	ui.add_child(l)
	return l


func _layout(mode: int) -> Dictionary:
	match mode:
		Mode.COYOTE:
			return {"spawn": Vector2(40, 0), "hazards": [],
				"solids": [Rect2(0, 0, 320, 40), Rect2(464, 0, 336, 40)]}
		Mode.BUFFER:
			return {"spawn": Vector2(40, -100), "hazards": [],
				"solids": [Rect2(0, -100, 180, 140), Rect2(180, 0, 112, 40), Rect2(400, 0, 400, 40)]}
		_:
			return {"spawn": Vector2(40, 0), "hazards": [Rect2(300, -140, 240, 52)],
				"solids": [Rect2(0, 0, 800, 40), Rect2(400, -16, 16, 16)]}


func _build(index: int) -> void:
	for lane in lanes:
		lane.root.queue_free()
	lanes.clear()
	for l in lane_labels:
		l.queue_free()
	lane_labels.clear()

	var show: Dictionary = SHOWS[index]
	title.text = show.title
	sub.text = show.sub
	var px := Vector2(get_window().size) / 2.0
	var x0 := floorf((px.x - LANE_LEN) / 2.0)
	for i in 2:
		var on := i == 1
		var def := _layout(show.mode)
		var root := Node2D.new()
		root.position = Vector2(x0, floorf(px.y * (0.46 if i == 0 else 0.90)))
		world.add_child(root)

		var painter := Painter.new()
		painter.def = def
		root.add_child(painter)
		for r: Rect2 in def.solids:
			var body := StaticBody2D.new()
			body.position = r.get_center()
			body.add_child(_shape(r.size))
			root.add_child(body)

		var p := CharacterBody2D.new()
		p.set_script(PlayerScript)
		p.use_coyote = on or show.mode != Mode.COYOTE
		p.use_buffer = on or show.mode != Mode.BUFFER
		p.use_variable = on or show.mode != Mode.VARIABLE
		var shape := _shape(Vector2(24, 28))
		shape.position = Vector2(0, -14)
		p.add_child(shape)
		var look := Look.new()
		look.color = ON_COLOR if on else OFF_COLOR
		p.add_child(look)
		var pilot := Pilot.new()
		pilot.mode = show.mode
		p.pilot = pilot
		p.position = def.spawn
		root.add_child(p)

		var lane := {"root": root, "player": p, "pilot": pilot, "look": look, "spawn": def.spawn, "dead": false}
		lanes.append(lane)
		p.jumped.connect(_on_jumped.bind(lane))
		p.landed.connect(_on_landed.bind(lane))
		for r: Rect2 in def.hazards:
			var area := Area2D.new()
			area.position = r.get_center()
			area.add_child(_shape(r.size - Vector2(0, 2)))
			area.body_entered.connect(_on_hazard.bind(lane))
			root.add_child(area)

		var tag := _label(44, ON_COLOR if on else OFF_COLOR)
		tag.text = "켬" if on else "끔"
		tag.position = (root.position + Vector2(-34, -146)) * 2.0
		lane_labels.append(tag)


func _shape(size: Vector2) -> CollisionShape2D:
	var rect := RectangleShape2D.new()
	rect.size = size
	var shape := CollisionShape2D.new()
	shape.shape = rect
	return shape


func _physics_process(delta: float) -> void:
	clock += delta
	var want := int(clock / SECONDS_EACH) % SHOWS.size()
	if want != show_index:
		show_index = want
		_build(want)
		return
	for lane in lanes:
		if lane.dead:
			continue
		var p: CharacterBody2D = lane.player
		lane.pilot.update(p)
		if p.position.y > 70.0:
			_die(lane)
		elif p.position.x > LANE_LEN - 24.0:
			_respawn(lane)


func _process(delta: float) -> void:
	# The shake moves the picture, never the simulation, and stays on whole dots.
	shake = move_toward(shake, 0.0, delta * 24.0)
	world.position = Vector2(roundf(rng.randf_range(-shake, shake)), roundf(rng.randf_range(-shake, shake)))


func _on_jumped(lane: Dictionary) -> void:
	_squash(lane.look, Vector2(0.7, 1.35))
	_puff(lane, Color("c9c2e8"), 8, 70.0)
	_play("jump", lane)


func _on_landed(lane: Dictionary) -> void:
	_squash(lane.look, Vector2(1.35, 0.65))
	_puff(lane, Color("c9c2e8"), 10, 90.0)
	_play("land", lane)
	shake = maxf(shake, 1.5)


func _on_hazard(body: Node, lane: Dictionary) -> void:
	if body == lane.player:
		_die.call_deferred(lane)


func _die(lane: Dictionary) -> void:
	if lane.dead or not is_instance_valid(lane.player):
		return
	lane.dead = true
	var p: CharacterBody2D = lane.player
	_puff(lane, Color.WHITE, 26, 260.0)
	_puff(lane, lane.look.color, 20, 190.0)
	_play("die", lane)
	shake = 7.0
	p.visible = false
	p.set_physics_process(false)
	get_tree().create_timer(0.7).timeout.connect(_revive.bind(lane))


func _revive(lane: Dictionary) -> void:
	if is_instance_valid(lane.player):
		_respawn(lane)


func _respawn(lane: Dictionary) -> void:
	var p: CharacterBody2D = lane.player
	p.position = lane.spawn
	p.reset()
	p.visible = true
	p.set_physics_process(true)
	lane.pilot.reset()
	lane.dead = false


func _squash(look: Node2D, to: Vector2) -> void:
	look.scale = to
	look.create_tween().tween_property(look, "scale", Vector2.ONE, 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _puff(lane: Dictionary, color: Color, amount: int, speed: float) -> void:
	var dust := CPUParticles2D.new()
	dust.position = lane.player.position + Vector2(0, -4)
	dust.one_shot = true
	dust.explosiveness = 1.0
	dust.amount = amount
	dust.lifetime = 0.4
	dust.direction = Vector2.UP
	dust.spread = 80.0
	dust.initial_velocity_min = speed * 0.4
	dust.initial_velocity_max = speed
	dust.gravity = Vector2(0, 500)
	dust.scale_amount_min = 2.0
	dust.scale_amount_max = 2.0
	dust.color = color
	dust.finished.connect(dust.queue_free)
	lane.root.add_child(dust)
	dust.emitting = true


func _play(sound: String, lane: Dictionary) -> void:
	var a := AudioStreamPlayer2D.new()
	a.stream = sounds[sound]
	a.position = lane.player.position
	a.max_distance = 3000.0
	a.panning_strength = 2.0
	a.finished.connect(a.queue_free)
	lane.root.add_child(a)
	a.play()


## A short retro blip made in code: a square wave sliding from f0 to f1, mixed with noise.
func _tone(f0: float, f1: float, seconds: float, noise: float, volume: float) -> AudioStreamWAV:
	var rate := 22050
	var count := int(seconds * rate)
	var data := PackedByteArray()
	data.resize(count * 2)
	var phase := 0.0
	var hiss := RandomNumberGenerator.new()
	hiss.seed = 7
	for i in count:
		var t := float(i) / count
		phase += lerpf(f0, f1, t) / rate
		var s := (1.0 if fmod(phase, 1.0) < 0.5 else -1.0) * (1.0 - noise) + hiss.randf_range(-1.0, 1.0) * noise
		s *= volume * (1.0 - t) * (1.0 - t)
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = rate
	wav.data = data
	return wav
