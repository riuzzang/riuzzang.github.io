extends Node2D

var score = 0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Hud.text = "점수 " + str(score) + "  시간 " + str(int($Timer.time_left))


func _on_button_pressed() -> void:
	$Firework.restart()

func add_score():
	score += 1


func _on_timer_timeout() -> void:
	$Hud.text = "끝! 점수 " + str(score)
	get_tree().paused = true
